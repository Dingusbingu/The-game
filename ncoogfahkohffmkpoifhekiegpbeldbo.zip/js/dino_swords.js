window.__NUXT__ = {
    layout: "default",
    data: [{}],
    fetch: [],
    error: null,
    serverRendered: !0,
    routePath: "/",
    config: {}
}